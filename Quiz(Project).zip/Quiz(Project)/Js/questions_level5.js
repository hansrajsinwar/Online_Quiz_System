// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "How many stars make up the Big Dipper?",
    answer: "7 stars",
    options: [
      "2 stars",
      "100 stars",
      "7 stars",
      "1 million"
    ]
  },
    {
    numb: 2,
    question: "What are the storms produced by the sun called?",
    answer: "Solar storms",
    options: [
      "Vortex",
      "Solar storms",
      "Great red spot",
      "None of these"
    ]
  },
    {
    numb: 3,
    question: "Which constellation represents a hunter and weapons?",
    answer: "Orion",
    options: [
      "Grus",
      "Hercules",
      "Pegasus",
      "Orion"
    ]
  },
    {
    numb: 4,
    question: "Which constellation contains the stars Castor and Pollux?",
    answer: "Gemini",
    options: [
      "Ursa Major",
      "Ursa Minor",
      "Gemini",
      "Virgo"
    ]
  },
    {
    numb: 5,
    question: "Which constellation is shaped like a winged horse?",
    answer: "Pegasus",
    options: [
      "Little bear",
      "Vela",
      "Sail of the Argonauts' ship",
      "Pegasus"
    ]
  },
  
   {
     numb: 6,
     question: "What does a meteor become when it hits the Earth’s surface ?",
     answer: "Meteorite",
    options: [
       "Planetoid",
       "Asteroid",
       "Meteorite",
       "Auroral Storm"
     ]
   },
   
   {
      numb: 7,
     question: "Which star is nearest to Earth? (Hint: It’s not the sun!)",
     answer: "Alpha Centauri",
    options: [
       "The moon",
       "Alpha Centauri",
       "Proxima Centauri",
       "Rigel"
     ]
   },
   { numb: 8,
     question: "Which astrological sign becomes visible starting January 21st?",
     answer: "Aquaris",
    options: [
       "Aquaris",
       "Big Bear",
       "Scorpion",
       "Sculptor's tools"
     ]
   },
   {
   numb: 9,
     question: "What is the polarity reversal of the sun?",
     answer: "Solar cycle",
    options: [
       "Zodiacal belt",
       "Solar cycle",
       "Orbit",
       "Solar debris"
     ]
   },
   {
   numb: 10,
     question: "Vesta is which type of celestial body?",
     answer: "An asteroid",
    options: [
       "A star",
       "Dwarf planet",
       "An asteroid",
       "Meteorite"
     ]
   },
];