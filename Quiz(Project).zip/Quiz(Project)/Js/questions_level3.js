// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which planet spins backward relative to the others?",
    answer: "Venus",
    options: [
      "Earth",
      "Jupiter",
      "Venus",
      "Mars"
    ]
  },
    {
    numb: 2,
    question: "Who was the first woman to travel into space?",
    answer: "Valentina Tereshkova",
    options: [
      "Judith Resnik",
      "Valentina Tereshkova",
      "Sunita Williams",
      "Wang Yaping"
    ]
  },
    {
    numb: 3,
    question: "What color is Mars' sunset?",
    answer: "Blue",
    options: [
      "Red",
      "Green",
      "Orange",
      "Blue"
    ]
  },
    {
    numb: 4,
    question: "How long does a solar eclipse last?",
    answer: "7.5 min",
    options: [
      "12 hrs",
      "7.5 min",
      "1 hr",
      "can't predict"
    ]
  },
    {
    numb: 5,
    question: "What is a comet made of?",
    answer: "Mixture of ice,dust and rocks",
    options: [
      "Mixture of ice,dust and rocks",
      "Lava",
      "Gaseous ball",
      "Mixture of mist and dust"
    ]
  },
  
   {
     numb: 6,
     question: "Which planet is known as the Evening Star?",
     answer: "Venus",
    options: [
       "Mars",
       "Saturn",
       "Venus",
       "Uranus"
     ]
   },
   
   {
      numb: 7,
     question: "Asteroids are also referred to as...?",
     answer: "Planetoids",
    options: [
       "Meteors",
       "Planetoids",
       "Dwarf Planets",
       "Space junk"
     ]
   },
   { numb: 8,
     question: "How many Earth could fit inside the sun?",
     answer: "1 million",
    options: [
       "8600",
       "100 million",
       "1 billion",
       "1 million"
     ]
   },
   {
   numb: 9,
     question: "What are the explosions of energy released by the sun's magnetic fields called?",
     answer: "Solar flares",
    options: [
       "Geomagnetic storm",
       "Solar flares",
       "Surge",
       "Radio blackouts"
     ]
   },
   {
   numb: 10,
     question: "Name the most famous asteroids?",
     answer: "All of these",
    options: [
       "Ceres",
       "Pallas",
       "Vesta",
       "All of these"
     ]
   },
];