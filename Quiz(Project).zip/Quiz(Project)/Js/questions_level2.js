// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which planet has the most moons?",
    answer: "Saturn",
    options: [
      "Jupiter",
      "Saturn",
      "Neptune",
      "Uranus"
    ]
  },
    {
    numb: 2,
    question: "Which is the oldest planet in our solar system?",
    answer: "Jupiter",
    options: [
      "Jupiter",
      "Venus",
      "Saturn",
      "Mars"
    ]
  },
    {
    numb: 3,
    question: "Which planet has supersonic winds?",
    answer: "Neptune",
    options: [
      "Mars",
      "Jupiter",
      "Earth",
      "Neptune"
    ]
  },
    {
    numb: 4,
    question: "How many of our planets can be seen without a telescope?",
    answer: "5",
    options: [
      "5",
      "2",
      "0",
      "1"
    ]
  },
    {
    numb: 5,
    question: "Which planet has Phobos and Deimos as its moons?",
    answer: "Mars",
    options: [
      "Jupiter",
      "venus",
      "Saturn",
      "Mars"
    ]
  },
  
   {
     numb: 6,
     question: "Which is the densest planet in our solar system?",
     answer: "Earth",
    options: [
       "Earth",
       "Jupiter",
       "Venus",
       "Saturn"
     ]
   },
   
   {
      numb: 7,
     question: "Which planet is known as the Morning Star?",
     answer: "Venus",
    options: [
       "Saturn",
       "Venus",
       "Sun",
       "Proxima Century"
     ]
   },
   { numb: 8,
     question: "Which planet rotates on its side?",
     answer: "Uranus",
    options: [
       "Earth",
       "Uranus",
       "Venus",
       "Jupiter"
     ]
   },
   {
   numb: 9,
     question: "Which of the following are recognised as dwarf planets?",
     answer: "All of these",
    options: [
       "Pluto and Ceres",
       "Only Eris",
       "Makemake and Haumea",
       "All of these"
     ]
   },
   {
   numb: 10,
     question: "Which planet has the most volcanoes?",
     answer: "Venus",
    options: [
       "Jupiter",
       "Earth",
       "Venus",
       "Neptune"
     ]
   },
];