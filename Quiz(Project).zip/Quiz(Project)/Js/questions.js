// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which panet has moon called 'Titan Orbits'?",
    answer: "Saturn",
    options: [
      "Mercury",
      "jupiter",
      "Saturn",
      "Mars"
    ]
  },
    {
    numb: 2,
    question: "Which is the only spacecraft that has visited Uranus?",
    answer: "Voyager 2",
    options: [
      "Soyuz",
      "Shenzhou",
      "Crew Dragon",
      "Voyager 2"
    ]
  },
    {
    numb: 3,
    question: "Which planets have no moon?",
    answer: "Mercury and Venus",
    options: [
      "Mercury and Venus",
      "Uranus and neptune",
      "Mars and jupiter",
      "Mars and venus"
    ]
  },
    {
    numb: 4,
    question: "Which is the smallest planet in our solar system?",
    answer: "Mercury",
    options: [
      "Venus",
      "Mars",
      "Neptune",
      "Mercury"
    ]
  },
    {
    numb: 5,
    question: "How long is one year on Jupiter?",
    answer: "12 Earth years",
    options: [
      "12 Earth years",
      "14 Earth years",
      "3 Earth years",
      "26 Earth years"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

   {
     numb: 6,
     question: "Which planet has the fastest rotation?",
     answer: "Jupiter",
    options: [
       "Earth",
       "Jupiter",
       "Venus",
       "Mars"
     ]
   },
   
   {
      numb: 7,
     question: "Which is the brightest planet in the night’s sky?",
     answer: "Venus",
    options: [
       "Mars",
       "Venus",
       "Mercury",
       "Saturn"
     ]
   },
   { numb: 8,
     question: "How many moons does Earth have?",
     answer: "Just one!",
    options: [
       "Two",
       "Just one!",
       "Ten",
       "None"
     ]
   },
   {
   numb: 9,
     question: "In which year Pluto was reclassified as a dwarf planet?",
     answer: "2006",
    options: [
       "2006",
       "1997",
       "2001",
       "2018"
     ]
   },
   {
   numb: 10,
     question: "Which planet is closest in size to Earth?",
     answer: "Venus",
    options: [
       "Mars",
       "Jupiter",
       "Venus",
       "Mercury"
     ]
   },
];